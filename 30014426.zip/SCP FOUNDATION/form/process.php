<?php

require '../data/connection.php';
 // Insert Data to database


 if(isset($_POST['submit']))
    {
        $id = $_POST['id'];
        $item = $_POST['item'];
        $object_class = $_POST['object_class'];
        $image = $_POST['image'];
        $procedures = $_POST['procedures'];
        $description = $_POST['description'];
        $reference = $_POST['reference'];

        $sql = "insert into subject (item, object_class, image, procedures, description, reference) values('$item','$object_class','$image','$procedures','$description','$reference')";
          
        if($connection->query($sql) === TRUE)
        {
            
            echo"<p>Record was Created. <a href='../index.php'>Return to index page</a></p>";
            header("Location: ../index.php");
        }
        else
        {
            echo"
                <p>there was an error Creating this record.</p>
                <p{$connection->error()}></p>
                <p><a href='../index.php'>back to index page</a></p>
                
                ";
                header("Location: ../index.php");
        }
        
    }



// delete data in db

if(isset($_GET['delete']))
    {
        $id = $_GET['delete'];
        
        //create delete sql
        $del = "delete from subject where id=$id ";
        
        if($connection->query($del) === TRUE)
        {
            
            echo"<p>Record was deleted. <a href='../index.php'>Return to index page</a></p>";
            header("Location: ../index.php");
        }
        else
        {
            echo"
                <p>there was an error deleting this record.</p>
                <p{$connection->error()}></p>
                <p><a href='../index.php'>back to index page</a></p>
                
                ";
                header("Location: ../index.php");
        }
       
          
    }
    if(isset($_POST['update']))
 {
     // update all $_POST values from form into separate variables
        $id = $_POST['id'];
        $item = $_POST['item'];
        $object_class = $_POST['object_class'];
        $image = $_POST['image'];
        $procedures = $_POST['procedures'];
        $description = $_POST['description'];
        $reference = $_POST['reference'];

     $update = "update subject set item='$item', object_class='$object_class', image='$image',procedures='$procedures', description='$description', reference='$reference'where id='$id'";

     if ($connection->query($update) === TRUE) 
     {
        echo"<p>Record was Update. <a href='../index.php'>Return to index page</a></p>";
     } 
     else 
     {
         echo"
        <p>there was an error updating this record.</p>
        <p{$connection->error()}></p>
        <p><a href='../index.php'>back to index page</a></p>
        
        ";
     }

     
  
 }


?>