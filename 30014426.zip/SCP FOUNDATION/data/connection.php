
<?php

    // Create Database credential variables
    $user = "a30014426";
    $password = "nevilandrews9";
    $db = "a3001442_SCP";

    // Create php db connection object
    $connection = new mysqli('localhost', $user, $password, $db) or die(mysqli_error($connection));

    // Get all data from the table and save in a variable for use on our page application
    $result = $connection->query("select * from subject") or die($connection->error());


          
?>
